$('.slider').on("click", slide);
var page = "first"

function slide() {
  if (page === "first") {
    $('.text-header').text("Increased moisture helps your skin to repair and prevent damage.");
    $('.img-h').attr("src","water.jpg");
    page = "second";
    //makes sure that on the second run, the function goes to else
  } else if (page === "second") {
    $('.text-header').text("Powerhouse ingredients to fight visible signs of aging.");
    $('.img-h').attr("src", "https://slimages.macysassets.com/is/image/MCY/products/5/optimized/17799005_fpx.tif?op_sharpen=1&wid=700&hei=855&fit=fit,1");
    page = "third";
  } else {
    $('.text-header').text("Fast Visible Repair and Youth-Generating Power.");
    $('.img-h').attr("src", "model.png");
    page = "first";
    //similar to original secrets = "shown"
  }
}

var georgiaPin = $(".second");
var georgiaInfo = $(".secondInfo");

georgiaPin.on("mouseover", displayInfo); //flips the hide or not-hide switch when hovered over
georgiaPin.on("mouseout", displayInfo); //flips the hide or not-hide switch when stopped hovering over

function displayInfo(event) {
  event.preventDefault(); //just add this in for good measure even though we're not using forms!
  georgiaInfo.toggleClass("hidden"); //toggles the class "hidden" ON and OFF
}
//Let's practice with Texas! Step 1: Declare the variables 
var texasPin = $(".first");
var texasInfo = $(".firstInfo");

texasPin.on("mouseover", displayInfo); //flips the hide or not-hide switch when hovered over
texasPin.on("mouseout", displayInfo); //flips the hide or not-hide switch when stopped hovering over

function displayInfo(event) {
  event.preventDefault(); //just add this in for good measure even though we're not using forms!
  texasInfo.toggleClass("hidden"); //toggles the class "hidden" ON and OFF
}

//event listener 


//event handler 
